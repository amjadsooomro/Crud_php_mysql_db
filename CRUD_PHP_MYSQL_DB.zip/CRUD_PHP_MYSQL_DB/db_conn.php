<?php 

$conn=mysqli_connect("localhost","root","","crud_db");
if($conn){
   // echo "connected!";
}else{
	echo "not! connected";
}
?>
