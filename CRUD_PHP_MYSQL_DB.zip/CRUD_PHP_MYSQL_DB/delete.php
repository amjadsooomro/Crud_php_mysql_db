<?php
include("db_conn.php"); 
$id = $_GET['id'];

echo $query="DELETE FROM student where id = ".$id;
$res=mysqli_query($conn,$query);
if($res){
	header("location:read.php?");
 }
 else{
header("location:delet.php?"); 	
 }

 ?>
